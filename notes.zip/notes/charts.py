

from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")          # saves to files; no pop-up windows
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

BASE = Path(__file__).resolve().parent.parent   # project root
CHARTS = BASE / "charts"
CHARTS.mkdir(exist_ok=True)
sns.set_theme(style="whitegrid")

CLEANED = BASE / "dataset" / "online_retail_cleaned.csv"
RAW = BASE / "dataset" / "online_retail_II.csv"


# ---------- 1. Load data (robust to column-name differences) ----------
def standardise_columns(df):
    """Rename columns so 'invoicedate', 'Invoice Date', 'invoice_date' etc. all work."""
    wanted = {
        "invoice": "Invoice",
        "invoiceno": "Invoice",
        "invoicedate": "InvoiceDate",
        "customerid": "Customer ID",
        "quantity": "Quantity",
        "price": "Price",
        "unitprice": "Price",
        "revenue": "Revenue",
        "totalprice": "Revenue",
        "totalamount": "Revenue",
        "country": "Country",
    }
    rename = {}
    for col in df.columns:
        key = "".join(ch for ch in str(col).lower() if ch.isalnum())
        if key in wanted and wanted[key] not in rename.values():
            rename[col] = wanted[key]
    return df.rename(columns=rename)


def clean_raw(df):
    df = df.dropna(subset=["Customer ID"])
    df = df[~df["Invoice"].astype(str).str.startswith("C")]   # cancellations
    df = df[(df["Quantity"] > 0) & (df["Price"] > 0)]
    return df


def load_data():
    needed = ["Invoice", "InvoiceDate", "Customer ID"]
    path = CLEANED if CLEANED.exists() else RAW
    df = standardise_columns(pd.read_csv(path))
    print(f"Loaded {path.name}: {len(df):,} rows. Columns: {list(df.columns)}")

    if not all(c in df.columns for c in needed):
        if path == CLEANED and RAW.exists():
            print("Cleaned file is missing needed columns -> using raw file instead.")
            df = standardise_columns(pd.read_csv(RAW))
            df = clean_raw(df)
        else:
            raise SystemExit(f"Missing columns. Need {needed}, found {list(df.columns)}")
    elif path == RAW:
        df = clean_raw(df)

    df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"])
    df = df.dropna(subset=["Customer ID"])
    if "Revenue" not in df.columns:
        df["Revenue"] = df["Quantity"] * df["Price"]
    df = df[df["Revenue"] > 0]
    return df


df = load_data()
print(f"Using {len(df):,} rows, {df['Customer ID'].nunique():,} customers")

# ---------- 2. RFM table ----------
snapshot = df["InvoiceDate"].max() + pd.Timedelta(days=1)
rfm = df.groupby("Customer ID").agg(
    Recency=("InvoiceDate", lambda x: (snapshot - x.max()).days),
    Frequency=("Invoice", "nunique"),
    Monetary=("Revenue", "sum"),
)

# ---------- 3. K-Means on log-scaled RFM ----------
X = StandardScaler().fit_transform(np.log1p(rfm[["Recency", "Frequency", "Monetary"]]))

ks = range(2, 9)
inertia, sil = [], []
for k in ks:
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X)
    inertia.append(km.inertia_)
    sil.append(silhouette_score(X, km.labels_, sample_size=5000, random_state=42))

K = 4
rfm["Cluster"] = KMeans(n_clusters=K, n_init=10, random_state=42).fit_predict(X)

# Name clusters from their average R/F/M (rule-based, so names match behaviour)
prof = rfm.groupby("Cluster")[["Recency", "Frequency", "Monetary"]].mean()
champ = prof["Monetary"].idxmax()                         # biggest spenders
lost = prof.drop(champ)["Recency"].idxmax()               # longest silent
rest = prof.drop([champ, lost]).sort_values("Recency")    # remaining two
recent, slipping = rest.index[0], rest.index[1]
label = {champ: "Champions", recent: "New / Promising",
         slipping: "At-Risk", lost: "Lost"}
rfm["Segment"] = rfm["Cluster"].map(label)
seg_order = ["Champions", "New / Promising", "At-Risk", "Lost"]

# ---------- Chart 1: monthly revenue ----------
try:
    monthly = df.set_index("InvoiceDate")["Revenue"].resample("ME").sum()
except ValueError:                       # older pandas uses "M"
    monthly = df.set_index("InvoiceDate")["Revenue"].resample("M").sum()
fig, ax = plt.subplots(figsize=(10, 4))
monthly.plot(ax=ax, marker="o")
ax.set_title("Monthly Revenue (note the Q4 peaks)")
ax.set_ylabel("Revenue (£)"); ax.set_xlabel("")
fig.tight_layout(); fig.savefig(CHARTS / "1_monthly_revenue.png", dpi=150); plt.close(fig)

# ---------- Chart 2: RFM distributions ----------
fig, ax = plt.subplots(1, 3, figsize=(14, 4))
sns.histplot(rfm["Recency"], bins=40, ax=ax[0]);              ax[0].set_title("Recency (days)")
sns.histplot(np.log1p(rfm["Frequency"]), bins=40, ax=ax[1]);  ax[1].set_title("Frequency (log)")
sns.histplot(np.log1p(rfm["Monetary"]), bins=40, ax=ax[2]);   ax[2].set_title("Monetary (log)")
fig.tight_layout(); fig.savefig(CHARTS / "2_rfm_distributions.png", dpi=150); plt.close(fig)

# ---------- Chart 3: elbow + silhouette ----------
fig, ax = plt.subplots(1, 2, figsize=(11, 4))
ax[0].plot(list(ks), inertia, marker="o"); ax[0].set_title("Elbow Method"); ax[0].set_xlabel("k"); ax[0].set_ylabel("Inertia")
ax[1].plot(list(ks), sil, marker="o", color="darkorange"); ax[1].set_title("Silhouette Score"); ax[1].set_xlabel("k")
for a in ax: a.axvline(K, ls="--", color="grey")
fig.tight_layout(); fig.savefig(CHARTS / "3_choosing_k.png", dpi=150); plt.close(fig)

# ---------- Chart 4: customers vs revenue share ----------
share = rfm.groupby("Segment").agg(Customers=("Monetary", "size"), Revenue=("Monetary", "sum")).loc[seg_order]
share = share / share.sum() * 100
fig, ax = plt.subplots(figsize=(9, 4.5))
share.plot(kind="bar", ax=ax, color=["#8da0cb", "#66c2a5"])
ax.set_ylabel("% of total"); ax.set_xlabel(""); ax.set_title("Share of Customers vs Share of Revenue")
plt.xticks(rotation=0)
fig.tight_layout(); fig.savefig(CHARTS / "4_segment_share.png", dpi=150); plt.close(fig)

# ---------- Chart 5: segment profile heatmap ----------
profile = rfm.groupby("Segment")[["Recency", "Frequency", "Monetary"]].mean().loc[seg_order]
fig, ax = plt.subplots(figsize=(7, 4))
sns.heatmap(profile.round(0), annot=True, fmt=",.0f", cmap="YlGnBu", ax=ax)
ax.set_title("Average R / F / M by Segment"); ax.set_ylabel("")
fig.tight_layout(); fig.savefig(CHARTS / "5_segment_profile.png", dpi=150); plt.close(fig)

# ---------- Save the RFM table (deliverable) ----------
rfm.reset_index().to_csv(BASE / "rfm_table.csv", index=False)
print(rfm["Segment"].value_counts())
print(profile.round(1))
print("Done. Charts saved to", CHARTS)