import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_theme(style="whitegrid")
plt.rcParams["figure.figsize"] = (10, 5)

df = pd.read_csv("dataset/online_retail_II.csv")

print(df.shape)
df.info()
print(df.isna().sum())
print(df.head())

# a copy of the dataset
clean_df = df.copy()

# Remove exact duplicate rows
clean_df = clean_df.drop_duplicates()

# Remove rows that are completely empty
clean_df = clean_df.dropna(subset=["Customer ID"])

# Standardize column names
clean_df.columns = (
    clean_df.columns
    .str.strip()
    .str.lower()
    .str.replace(" ", "_", regex=False)
)

# Remove leading and trailing spaces from text values
text_columns = clean_df.select_dtypes(
    include=["object", "string"]
).columns

for column in text_columns:
    clean_df[column] = clean_df[column].str.strip()

#checking after cleaning
print("\n========== AFTER CLEANING ==========")

print("Shape (rows, columns):", clean_df.shape)

print("\nDataset information:")
clean_df.info()

print("\nFirst 5 cleaned rows:")
print(clean_df.head())

print("\nMissing values per column:")
print(clean_df.isna().sum())

print("\nTotal missing values:", clean_df.isna().sum().sum())

print("\nDuplicate rows:", clean_df.duplicated().sum())

print("\nData types:")
print(clean_df.dtypes)

print("\n========== CLEANING SUMMARY ==========")

print("Original rows:", len(df))
print("Rows after cleaning:", len(clean_df))
print("Rows removed:", len(df) - len(clean_df))

print("Original columns:", len(df.columns))
print("Columns after cleaning:", len(clean_df.columns))

print("Duplicates before:", df.duplicated().sum())
print("Duplicates after:", clean_df.duplicated().sum())

print(
    "Missing values before:",
    df.isna().sum().sum()
)

print(
    "Missing values after:",
    clean_df.isna().sum().sum()
)


# cleaned dataset saved
from pathlib import Path
output_path =Path("dataset/online_retail_cleaned.csv")

clean_df.to_csv(output_path, index=False)

print("\nCleaned dataset saved to:", output_path.resolve())
print("\nCleaning and validation completed!")